/**
 * Kyla Kane-Maystead
 * Assignment 2
 * This class is designed to test the evaluate method in the PostfixExpression class
 */
package cs2321;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PostfixExpressionTest {

	PostfixExpression post;
	
	@Before
	public void setUp() throws Exception {
		post = new PostfixExpression();
	}

	@Test
	public void test1() {
		assertEquals("base", 3, post.evaluate("3"));
	}
	
	@Test
	public void test2() {
		assertEquals("simple", 9, post.evaluate("17 8 -"));
	}
	
	@Test
	public void test3() {
		assertEquals("hard", 94, post.evaluate("4 20 5 + * 6 -"));
	}
	
	@Test
	public void test4() {
		assertEquals("complicated", 757, post.evaluate("100 200 + 2 / 5 * 7 +"));
	}
	
	@Test
	public void test5() {
		assertEquals("empty", 0, post.evaluate(""));
	}
	
	@Test
	public void test6() {
		assertEquals("operand only", 0, post.evaluate("/"));
	}
}
 