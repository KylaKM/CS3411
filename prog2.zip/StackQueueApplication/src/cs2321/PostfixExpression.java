/**
 * Kyla Kane-Maystead
 * Assignment 2
 * This class is designed to evaluate a postfix expression using an ArrayListStack
 */
package cs2321;

public class PostfixExpression {	
	/**
	 * Evaluate a postfix expression. 
	 * Postfix expression notation has operands first, following by the operations.
	 * For example:
	 *    13 5 *           is same as 13 * 5 
	 *    4 20 5 + * 6 -   is same as 4 * (20 + 5) - 6  
	 *    
	 * In this homework, expression in the argument only contains
	 *     integer, +, -, *, / and a space between every number and operation. 
	 * You may assume the result will be integer as well. 
	 * 
	 * @param exp The postfix expression
	 * @return the result of the expression
	 */
	public int evaluate(String exp) {
		int result = 0;   // Holds resulting number after evaluating expression
		int num1, num2;	  // Holds the two numbers that get popped off after there is an operand
		ArrayListStack<Integer> post = new ArrayListStack<Integer>();  // Creates an ArrayListStack object to hold the numbers
		if(exp.length() == 1) {	// If exp only holds one integer, return that integer
			if(exp.contains("+") || exp.contains("-") || exp.contains("/") || exp.contains("*"))
				return 0;
			return Integer.parseInt(exp);
		}
		if(exp.length() == 0)	// If exp is empty, return 0
			return 0;
		String[] str = exp.split(" ");	// Split exp by spaces and put into string array
		for(int i = 0; i < str.length; i++) {   // Loop through string array
			String temp = str[i];
			if(!"+".equals(temp) && !"*".equals(temp) && !"-".equals(temp) && !"/".equals(temp)) // If temp is a number, push it onto the stack
				post.push(Integer.parseInt(temp));
			else {
				String op = temp;	// Holds the operand
				num1 = post.pop();	// Holds first number to pop off stack
				num2 = post.pop();	// Holds second number to pop off stack
				if (op.equals("/"))		// If operand is "/", divide num1 by num2
					result = num2 / num1;  
				else if(op.equals("*")) // If operand is "*", times num1 by num2
					result = num1 * num2;
				else if(op.equals("+"))	 // If operand is "+", add num1 and num2 together
					result = num1 + num2;
				else if(op.equals("-"))   // If operand is "-", do num2 - num1
					result = num2 - num1;
				post.push(result);  // push result onto stack
			}
		}
		return result;
	}
}