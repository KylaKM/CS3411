/**
 * Kyla Kane-Maystead
 * Assignment 2
 * This class is designed to simulate the Josephus game with a CircularArrayQueue
 */
package cs2321;

public class Josephus {
	/**
	 * All persons sit in a circle. When we go around the circle, initially starting
	 * from the first person, then the second person, then the third... 
	 * we count 1,2,3,..k. The k-th person is out. Then we restart 
	 * the counting from the next person, go around, the k-th person 
	 * is out. Keep going the same way, when there is only one person left, she/he is the winner. 
	 *  
	 * @parameter persons  an array of string which contains all player names.
	 * @parameter k  an integer specifying the k-th person will be kicked out of the game
	 * @return return a doubly linked list in the order when the players were out of the game. 
	 *         the last one in the list is the winner.  
	 */
	public DoublyLinkedList<String> order(String[] persons, int k ) {
		CircularArrayQueue<String> people = new CircularArrayQueue<String>(persons.length);  // Creates new CircularArrayQueue object to people in game
		DoublyLinkedList<String> result = new DoublyLinkedList<String>();  	// Creates new DoublyLinkedList object to hold the people as they become out
		for(int i = 0; i < persons.length; i++) {  // Loops through persons array
			people.enqueue(persons[i]); 	// Adds people to CircularArrayQueue object
		}
		while(people.size() != 0) {		// Loops while moving around the circle
			for(int j = 0; j < k - 1; j++) {
				people.enqueue(people.dequeue());   
			}
			result.addLast(people.dequeue());  // Dequeues the person that is out into DoublyListObject
		}
		return result;
	}	
}