/**
 * Kyla Kane-Maystead
 * Assignment 2
 * This class is designed to check whether a string of parentheses is balanced or not.
 */
package cs2321;

public class MatchParentheses {
	/**
	 * 
	 * @param parenthesis a string of parentheses, such as "()", "()((()(())" 
	 * @return check if the closing parentheses match the open parentheses 
	 * 			in the correct order, that is "(" appears before ")".  
	 */
	public boolean match(String parenthesis) {
		ArrayListStack<String> par = new ArrayListStack<String>();	 // Creates an ArrayListStack object
		char[] str = parenthesis.toCharArray(); 	// Converts parenthesis to char array
		for (int i = 0; i < str.length; i++) {		// Loops through array
			if(str[i] == '(') {		// If character = ( then push it onto stack
				par.push("(");
			}
			else if(str[i] == ')') {	// If character = ) then pop a parenthesis off the stack
				if(par.isEmpty())		// If stack is empty, return false
					return false;
				par.pop();
			}
		}
		if(par.isEmpty())		// If stack is empty at the end, then it is true otherwise return false
			return true;
		return false;
	}
}