/**
 * Kyla Kane-Maystead
 * Assignment 1
 * This class is designed to create an array list structure.
 */
package cs2321;

import java.util.NoSuchElementException;
import java.util.Iterator;

import net.datastructures.List;

public class ArrayList<E> implements List<E> {
	
	public class IteratorClass implements Iterator<E> {
		
		private int j = 0;		//Index of next element to check
		private boolean removable = false;
		
		@Override
		public boolean hasNext() {
			return j < size;
		}

		@Override
		@TimeComplexity("O(1)")
		public E next() throws NoSuchElementException {
			/* TCJ
			 * This method returns the next element depending
			 * on where the index is, so it only goes through
			 * 1 element.
			 */
			if(j == size)
				throw new NoSuchElementException("No next element");
			removable = true;		//This element can be removed
			return data[j++];
		}
		
		/**
		 * This method removes a certain element from 
		 * an array depending on where the index is. 
		 * @throws IllegalStateException if there is nothing
		 * to remove (array is empty)
		 */
		@TimeComplexity("O(1)")
		public void remove() throws IllegalStateException {
			/* TCJ
			 * This method removes a certain element from
			 * the array so it would only go through 1 element.
			 */
			if(!removable)
				throw new IllegalStateException("Nothing to remove");
			ArrayList.this.remove(j - 1);		//last one returned
			j--;								//next element has shifted one cell to left
			removable = false;					//do not allow remove again until next is called
		}
		
	}
	
	// Instance Variables
	public static final int CAPACITY = 16;
	private E[] data;
	protected int size = 0;
	
	// Constructors
	public ArrayList() {
		this(CAPACITY);
	}
	
	/**
	 * 
	 * @param capacity of array
	 */
	public ArrayList(int capacity) {
		data = (E[]) new Object[capacity];
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	@Override
	public E get(int i) throws IndexOutOfBoundsException {
		checkIndex(i, size);
		return data[i];
	}

	@Override
	@TimeComplexity("O(1)")
	public E set(int i, E e) throws IndexOutOfBoundsException {
		/* TCJ
		 * This method sets a certain index of an array to an 
		 * element so it would only go through 1 element. 
		 */
		checkIndex(i, size);
		E temp = data[i];
		data[i] = e;
		return temp;
	}

	@Override
	@TimeComplexity("O(n)")
	public void add(int i, E e) throws IndexOutOfBoundsException {
		/* TCJ
		 * This method will add an element at a certain index
		 * in an array. At worst case, the element will needed
		 * to be added at the beginning of the array so it would
		 * go through n elements. 
		 */
		checkIndex(i, size + 1);
		if(size == data.length)			// not enough capacity
			resize(2 * data.length);	// double capacity
		for(int k = size - 1; k >= i; k--) 		// start by shifting rightmost
			data[k + 1] = data[k];
		data[i] = e;							// ready to place the new element
		size++;
	}
	
	@Override
	@TimeComplexity("O(n)")
	public E remove(int i) throws IndexOutOfBoundsException {
		/* TCJ
		 * All elements from i + 1 have to shift to last element have to shift
		 * to the left.
		 * The number of shifting is n - i. At worst case, you have to shift n
		 * elements so the big oh for the remove method is O(n).
		 */
		checkIndex(i, size);
		if(size == data.length)
			resize(2 * data.length);
		E temp = data[i];
		for(int k = i; k < size - 1; k++)
			data[k] = data[k + 1];
		data[size - 1] = null;
		size--;
		return temp;
	}
	
	/**
	 * Checks the index of where an element will be added or
	 * removed in an array to make sure it is in the array.
	 * @param i index that where an element will be added
	 * @param n size of array to be checked against index
	 * @throws IndexOutOfBoundsException if the index parameter
	 * is less than 0 or greater than or equal to n.
	 */
	protected void checkIndex(int i, int n) throws IndexOutOfBoundsException {
		if (i < 0 || i >= n) 		// Checks if given index is between 0 and n-1
			throw new IndexOutOfBoundsException("Illegal Index: " + i);
	}
	
	@Override
	public Iterator<E> iterator() {
		return new IteratorClass();
	}

	/**
	 * Adds element to beginning of the array and shifts the rest of the 
	 * elements to the right
	 * @param e element that needs to be added to array
	 * @throws IndexOutOfBoundsException if element parameter is equal
	 * to null
	 */
	@TimeComplexity("O(n)")
	public void addFirst(E e) throws IndexOutOfBoundsException {
		/* TCJ
		 * This method goes through n - 1 elements to add the first 
		 * element and shift the rest to the right.
		 */
		if(e == null)
			throw new IndexOutOfBoundsException("Illegal Argument");
		if(size == data.length)
			resize(2 * data.length);
		for(int i = size - 1; i > 0; i--) {
			data[i + 1] = data[i];
		}
		data[0] = e;
		size++;
	}
	
	/**
	 * Adds element to end of the array
	 * @param e element to be added to array
	 * @throws IndexOutOfBoundsException if the 
	 * element parameter is equal to null
	 */
	@TimeComplexity("O(1)")
	public void addLast(E e) throws IndexOutOfBoundsException {
		/* TCJ
		 * This method adds an element to the end of the array
		 * so it will only go through 1 element. 
		 */
		if(e == null)
			throw new IndexOutOfBoundsException("Illegal Argument");
		if(size == data.length)
			resize(2 * data.length);
		data[size] = e;
		size++;

	}
	
	/**
	 * This method removes the first element from the 
	 * array and shifts the rest of the elements to
	 * the right.
	 * @return the first element that gets removed
	 * @throws IndexOutOfBoundsException if the array is empty
	 */
	@TimeComplexity("O(n)")
	public E removeFirst() throws IndexOutOfBoundsException {
		/* TCJ
		 * This method will go through n elements as it will
		 * shift n - 2 elements to the right and remove the 
		 * n - 1 element. 
		 */
		if(isEmpty())
			throw new IndexOutOfBoundsException("Nothing to remove");
		if(size == data.length)
			resize(2 * data.length);
		E temp = data[0];
		for(int i = size - 1; i > 0; i--) {
			data[i + 1] = data[i];
		}
		size--;
		return temp; 
	}
	
	/**
	 * This method that returns and removes the last element. 
	 * @return the last element from the array that is getting removed
	 * @throws IndexOutOfBoundsException if array is empty
	 */
	@TimeComplexity("O(1)")
	public E removeLast() throws IndexOutOfBoundsException {
		/* TCJ
		 * This method only looks for one element to find and
		 * remove the last element.
		 */
		if(isEmpty())
			throw new IndexOutOfBoundsException("Nothing to remove");
		if(size == data.length)
			resize(2 * data.length);
		E temp = data[size - 1];
		size--;
		return temp;
	}
	
	// Return the capacity of array, not the number of elements.
	// Notes: The initial capacity is 16. When the array is full, the array should be doubled.
	public int capacity() {
		return data.length;
	}
	
	/**
	 * 
	 * @param capacity
	 */
	@TimeComplexity("O(n)")
	protected void resize(int capacity) {
		/* TCJ
		 * The method goes through n elements
		 * as it copies elements from one array
		 * to a new one.
		 */
		size = data.length;
		E[] temp = (E[]) new Object[capacity];		// Resizes internal array to have given capacity >= size
		for (int i = 0; i < size; i++)
			temp[i] = data[i];
		data = temp;
	}
}
