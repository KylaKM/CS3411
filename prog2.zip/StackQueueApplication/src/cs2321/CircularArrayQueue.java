/**
 * Kyla Kane-Maystead
 * Assignment 1
 * This class is designed to create a circular queue with
 * a fixed array.
 */
/**
 * Implement Queue ADT using a fixed-length array in circular fashion 
 *
 * @author ruihong-adm
 * @param <E> - formal type 
 *
 */

package cs2321;

import net.datastructures.Queue;

public class CircularArrayQueue<E> implements Queue<E> {

	// Instance Variables
	private E[] data;
	private int size = 0;
	private int front = 0;
	private int capacity = 0;
	
	public CircularArrayQueue(int c) {
		capacity = c;
		data = (E[]) new Object[c];
	}
	
	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	/* Throw IllegalStateException when the queue is full */
	@Override
	@TimeComplexity("O(1)")
	public void enqueue(E e) throws IllegalStateException {
		/* TCJ
		 * This method inserts an element into the queue
		 * utilizing the front pointer, size of the array, and
		 * its capacity so it only goes through 1 element.
		 */
		if(size == capacity)
			throw new IllegalStateException("Queue is full");
		data[(front + size) % capacity] = e;
		size++;
	}

	@Override
	@TimeComplexity("O(1)")
	public E first() {
		/* TCJ
		 * This method returns the first element in the queue
		 * in correlation with the front index so it only 
		 * goes through 1 element. 
		 */
		if(data[front] != null) {
			E temp = data[front];
			front++;
			return temp;
		}
		return null;
	}

	@Override
	@TimeComplexity("O(1)")
	public E dequeue() {
		/* TCJ
		 * This method returns the first element in the queue
		 * so it only goes through 1 element.
		 */
		if(size == 0)
			return null;
		E temp = data[front];
		front = (front + 1) % capacity;
		size--;
		return temp;
	}

}
