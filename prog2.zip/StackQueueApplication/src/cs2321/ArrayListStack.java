/**
 * Kyla Kane-Maystead
 * Assignment 2
 * This class is designed to create an ArrayListStack utilizing an ArrayList and a Stack
 */
package cs2321;

import net.datastructures.Stack;

public class ArrayListStack<E> extends ArrayList<E> implements Stack<E> {

	protected ArrayList<E> stack;  // Creates an ArrayList object

	public ArrayListStack() {      // Constructor
		stack = new ArrayList<E>();		// Initializes ArrayList object
	}

	@Override
	public int size() {
		return stack.size();  
	}

	@Override
	public boolean isEmpty() {
		return stack.size() == 0;	// If size of stack is zero return true, otherwise false
	}

	@Override
	public void push(E e) {
		stack.addLast(e);     // Mimics push by adding the element to the end
	}

	@Override
	public E top() {
		if(isEmpty())		// If stack is empty, return null
			return null;
		return stack.get(size() - 1);	// Mimics peek by returning element at the end
	}

	@Override
	public E pop() {
		if(isEmpty())   // If stack is empty, return null
			return null;
		return stack.removeLast();   // Mimics pop by removing last element
	}
}